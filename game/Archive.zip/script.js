// function randomString() {
//     var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
//     var string_length = 1;
//     var randomstring = '';
//     for (var i = 0; i < string_length; i++) {
//         var rnum = Math.floor(Math.random() * chars.length);
//         randomstring += chars.substring(rnum,rnum+1);
//     }
//     document.randform.randomfield.value = randomstring;
// }


// var words = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

// function next() {
//   turn = turn === 'A';
// }
// function play () {
//     if (this.innerHTML === '') {
//         this.innerHTML = turn;
//         checkForWinner();
//         next();
//     }
// }

// var squares = document.getElementById("board").getElementsByTagName("th");
//     for (var i in squares) {
//         squares[i].onclick = play;
//     }

// function checkForWinner() {

// }


//  function play() {
//        for (i = 0; i > 100; i++) {
//         this.innerHTML = rchar;
//       rchar =  random_character(); 




// var chars = "AAAAAAAAABBCCDDDDEEEEEEEEEEEEFFGGGHHIIIIIIIIIJKLLLLMMNNNNNNOOOOOOOOPPQRRRRRRSSSSTTTTTTUUUUVVWWXYYZ??";

// function random_character(chars) {
    
//     return this.chars.substr( Math.floor(Math.random() * 100), 1);
// }


// var rchar = random_character();
// this.chars = this.chars.replace(rchar.toString(), "");

// console.log(rchar);
// console.log(chars.length);

// function play() {
//        for (i = 0; i > 100; i++) {
//         this.innerHTML = rchar;
//       rchar =  random_character(); 
//        } 

// }

// var squares = document.getElementById("board").getElementsByTagName("th");
// for (var i in squares) {
//    squares[i].onclick = play;
// } 














// function random_character() {

//     var chars = "AAAAAAAAABBCCDDDDEEEEEEEEEEEEFFGGGHHIIIIIIIIIJKLL";
//     var string_length = 1;
//     var randomstring = '';
//     for (var i = 0; i < string_length; i++) {
//         var rnum = Math.floor(Math.random() * chars.length);
//         randomstring += chars.substring(rnum,rnum+1);
//     }
    
//     document.randform.randomfield.value = randomstring;


//     // return this.chars.substr( Math.floor(Math.random() * 100), 1);
// }


// var rchar = random_character();
// this.chars = this.chars.replace(rchar, "");

// console.log(rchar);
// console.log(chars.length);

// function play() {
//        for (i = 0; i > 100; i++) {
//         this.innerHTML = rchar;
//       rchar =  random_character(); 
//        } console.log("Game over!")
//        console.log(chars.length);
// }

// var squares = document.getElementById("board").getElementsByTagName("td");
// for (var i in squares) {
//    squares[i].onclick = play;
// } 

// console.log(rchar);
// console.log(chars.length);

// function makeid()
// {
//     var text = "";
//     var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

//     for( var i=0; i < 1; i++ )
//         text += possible.charAt(Math.floor(Math.random() * possible.length));

//     return text;
// }


var chars = "alligator";

function random_character(chars) {
    
    
}
String.prototype.shuffle = function () {
    
    var a = this.split(""),
        n = a.length;

    for(var i = n - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var tmp = a[i];
        a[i] = a[j];
        a[j] = tmp;
    }
    return a.join("");
}

var rchar = random_character();
// chars.replace(rchar.toString(), "");

console.log(rchar);

function play() {
        this.innerHTML = rchar;
        rchar = random_character();
}

var squares = document.getElementById("board").getElementsByTagName("td");
for (var i in squares) {
   squares[i].onclick = play;
}

 // $(document).on('click', function(event) {
 //    $( "#list" ).sortable({
 //      placeholder: "#list"
 //    });
 //    $( "#list" ).disableSelection();








